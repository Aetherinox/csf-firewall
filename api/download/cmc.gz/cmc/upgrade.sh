#!/bin/sh
###############################################################################
# Copyright 2006-2017, Way to the Web Limited
# URL: http://www.configserver.com
# Email: sales@waytotheweb.com
###############################################################################

if [ -e "/usr/local/cpanel/bin/register_appconfig" ]; then
    if [ -e "/usr/local/cpanel/whostmgr/docroot/cgi/addon_cmc.cgi" ]; then
        /usr/local/cpanel/bin/register_appconfig /usr/local/cpanel/whostmgr/docroot/cgi/configserver/cmc/cmc.conf

        /bin/rm -f /usr/local/cpanel/whostmgr/docroot/cgi/addon_cmc.cgi
        /bin/rm -f /usr/local/cpanel/whostmgr/docroot/cgi/cmcversion.txt
        /bin/rm -Rf /usr/local/cpanel/whostmgr/docroot/cgi/cmc
    fi
fi
