SHELL=/bin/sh
0 0 * * * root /usr/sbin/csf --lfd restart > /dev/null 2>&1
